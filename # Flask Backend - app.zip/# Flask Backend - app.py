# Flask Backend - app.py
from flask import Flask, request, jsonify, redirect
from flask_cors import CORS
import stripe
import os

app = Flask (__name__)
CORS(app)  # Enable CORS for React frontend

# Your Stripe secret key - replace with your actual key
stripe.api_key = 'sk_test_51Ro9jr7mMRcGOs8lZslujzzT2yqelJcssFw31FVvdQAyz6k1YWG2Wmw4ugYRmqZLXDI4eIm9VziwMreh6sfpU8P4000OwAhqLC'  # Replace with your actual Stripe secret key

# Your prce IDs from Stripe - replace with your actual price IDs
PRICES = {
    'compact': 'price_1RoA0S7mMRcGOs8luIhxs2TI',  # Replace with your $15/month price ID
    'premium': 'price_1Ro9y87mMRcGOs8l3F3268km'   # Replace with your $25/month price ID
}

@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    try:
        data = request.get_json()
        plan = data.get('plan')
        user_email = data.get('email', 'user@example.com')
        
        if plan not in PRICES:
            return jsonify({'error': 'Invalid plan'}), 400
        
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price': PRICES[plan],
                'quantity': 1,
            }],
            mode='subscription',
            customer_email=user_email,
            success_url='http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}',
            cancel_url='http://localhost:3000/cancel',
        )
        
        return jsonify({'checkout_url': checkout_session.url})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/webhook', methods=['POST'])
def webhook():
    # Handle Stripe webhooks here
    payload = request.get_data()
    sig_header = request.headers.get('Stripe-Signature')
    
    try:
        # Verify webhook signature (add your webhook secret)
        # event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'Flask backend is running!'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)