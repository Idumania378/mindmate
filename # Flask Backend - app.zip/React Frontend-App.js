// React Frontend - App.js
import React, { useState } from 'react';
import './App.css';

function App() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');

  const handleCheckout = async (plan) => {
    if (!email) {
      alert('Please enter your email address');
      return;
    }

    setLoading(true);
    
    try {
      const response = await fetch('http://localhost:5000/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          plan: plan,
          email: email
        }),
      });

      const data = await response.json();
      
      if (data.checkout_url) {
        // Redirect to Stripe Checkout
        window.location.href = data.checkout_url;
      } else {
        alert('Error creating checkout session: ' + data.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Network error. Please try again.');
    }
    
    setLoading(false);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Choose Your Plan</h1>
        
        <div className="email-input">
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="pricing-plans">
          <div className="plan-card">
            <h2>Compact Plan</h2>
            <p className="price">$15/month</p>
            <ul>
              <li>Basic features</li>
              <li>Email support</li>
              <li>5GB storage</li>
            </ul>
            <button 
              onClick={() => handleCheckout('compact')}
              disabled={loading}
              className="checkout-btn"
            >
              {loading ? 'Loading...' : 'Choose Compact'}
            </button>
          </div>

          <div className="plan-card">
            <h2>Premium Plan</h2>
            <p className="price">$25/month</p>
            <ul>
              <li>All features</li>
              <li>Priority support</li>
              <li>50GB storage</li>
              <li>Advanced analytics</li>
            </ul>
            <button 
              onClick={() => handleCheckout('premium')}
              disabled={loading}
              className="checkout-btn premium"
            >
              {loading ? 'Loading...' : 'Choose Premium'}
            </button>
          </div>
        </div>
      </header>
    </div>
  );
}

// Success Component
export function Success() {
  const urlParams = new URLSearchParams(window.location.search);
  const sessionId = urlParams.get('session_id');

  return (
    <div className="success-page">
      <h1>Payment Successful! 🎉</h1>
      <p>Thank you for your subscription!</p>
      {sessionId && <p>Session ID: {sessionId}</p>}
      <button onClick={() => window.location.href = '/'}>
        Back to Home
      </button>
    </div>
  );
}

// Cancel Component
export function Cancel() {
  return (
    <div className="cancel-page">
      <h1>Payment Cancelled</h1>
      <p>Your payment was cancelled. No charges were made.</p>
      <button onClick={() => window.location.href = '/'}>
        Try Again
      </button>
    </div>
  );
}

export default App;